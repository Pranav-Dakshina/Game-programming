﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingAssignment1
{
    /// <summary>
    /// Programming assignment to find the angle and distance between two points
    /// which are passed as input.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Programming assignment to find the angle and distance between two points
        /// which are passed as input.
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            //declaration of variables
            int pointX1;
            int pointY1;
            int pointX2;
            int pointY2;
            int deltaX;
            int deltaY;
            double distance;
            double angle;

            //Welcome Message
            Console.WriteLine("                                         WELCOME");
            Console.WriteLine(" This application will calculate the distance " +
                "between two points and the angle between those points.");
            Console.WriteLine();

            //get the input values
            Console.Write("Enter the x-axis value for the first point : ");
            pointX1 = int.Parse(Console.ReadLine());
            Console.Write("Enter the y-axis value for the first point : ");
            pointY1 = int.Parse(Console.ReadLine());

            Console.Write("Enter the x-axis value for the second point : ");
            pointX2 = int.Parse(Console.ReadLine());
            Console.Write("Enter the y-axis value for the second point : ");
            pointY2 = int.Parse(Console.ReadLine());

            //finding the difference between two points
            deltaX = pointX2 - pointX1;
            deltaY = pointY2 - pointY1;

            //computation of distance using Pythagores Theorem.
            distance = Math.Sqrt(Math.Pow(deltaX,2) + Math.Pow(deltaY,2));

            //angle made by the two points
            angle = (Math.Atan2(deltaY, deltaX) * 180 / Math.PI);
            
            //displaying the output message
            Console.WriteLine();
            Console.WriteLine("Distance between two points : " + distance.ToString("F3"));
            Console.WriteLine();
            Console.WriteLine("Angle between two points : " + angle.ToString("F3") + " degrees");
            Console.Read();

        }
    }
}
